const selectors = {
	sentence: ".sentence",
	noMistakeButton: ".noMistakeButton",
	nextButton: ".nextButton",
	understoodButton: ".understoodButton",
	buttonOk: ".buttonOk",
	exitButton: ".exitButton",
	answerWord: ".answerWord",
	playButton:
		".activity-selector-cell.singleRunnable .activity-selector-cell-container .activity-selector-cell-main",
	trainingEnd: ".trainingEndViewGoHome",
};

const ws = new WebSocket("wss://api.impin.fr/");
let understand = false;
let continueLearning = true;

ws.onopen = () => {};

ws.onmessage = (event) => {
	const result = JSON.parse(event.data);

	if (result.payload.correct === 1) {
		const noMistakeButton = document.querySelector(
			selectors.noMistakeButton
		);
		if (noMistakeButton) {
			noMistakeButton.click();
		}

		setTimeout(() => {}, 200);

		const spanAnswer = document.querySelector(
			"span[title='Mauvaise réponse']"
		);
		if (spanAnswer) {
			const answerWord = document.querySelector(selectors.answerWord);
			if (answerWord) {
				var sentence = document.querySelector(selectors.sentence);
				if (sentence) {
					sentence = sentence.innerText;
				}

				ws.send(
					JSON.stringify({
						type: "sentenceCheckAnswer",
						payload: {
							sentence: sentence,
							answerWord: answerWord.innerText,
						},
					})
				);
			}
		}
		const nextButton = document.querySelector(selectors.nextButton);
		if (nextButton) {
			nextButton.click();
		}
	} else if (result.payload.correct === 0) {
		var sentence = document.querySelector(selectors.sentence);
		let word = result.payload.incorrect_word
			.trim()
			.replace(/‑/g, " ")
			.split(/[\s'’.,;:!?\u2026]/)[0]
			.trim();
		if (word == "") {
			word = result.payload.incorrect_word
				.trim()
				.replace(/‑/g, " ")
				.split(/[\s'’.,;:!?\u2026]/)[1]
				.trim();
		}

		if (sentence) {
			const errorNode = Array.from(sentence.childNodes).find((node) => {
				// console.log(word);
				if (node.innerText.trim() === word) {
					return node;
				}
			});
			if (errorNode) {
				errorNode.click();
				const nextButton = document.querySelector(selectors.nextButton);
				if (nextButton) {
					nextButton.click();
				}
			}
		}
	}
};

function learnSpelling() {
	if (!continueLearning) {
		return;
	}

	var sentenceElement = document.querySelector(selectors.sentence);
	if (sentenceElement) {
		var sentence = sentenceElement.innerText;

		ws.send(
			JSON.stringify({
				type: "sentenceCheck",
				payload: sentence,
			})
		);
	}

	const understoodButton = document.querySelector(selectors.understoodButton);

	if (understoodButton && !understand) {
		understoodButton.click();
		understand = true;
	}

	if (understand) {
		var buttonOk = document.querySelectorAll(selectors.buttonOk);
		if (buttonOk) {
			buttonOk.forEach((element) => {
				element.click();
			});
		}

		var exitButton = document.querySelector(selectors.exitButton);
		if (exitButton) {
			exitButton.click();
		}

		understand = false;
	}
}

function main() {
	if (document.readyState === "complete") {
		const playButton = document.querySelector(selectors.playButton);
		const trainingEnd = document.querySelector(selectors.trainingEnd);
		if (playButton) {
			playButton.click();
		}
		if (trainingEnd) {
			trainingEnd.click();
		}
		learnSpelling();
	}
}

setInterval(main, 1300);
